from django.shortcuts import render,HttpResponse
from django.shortcuts import redirect
from rest_framework.response import Response
from . import models
from . import forms
import hashlib
import datetime
import json
from django.conf import settings
from django.http import JsonResponse
from rest_framework.decorators import api_view
# 引入dwbsocket的accept_websocket装饰器
from dwebsocket.decorators import accept_websocket
import uuid
import json
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
# 点击跳转到用户主页
def user(request):
    pass
    return render(request,'login/user.html')

# 主页
def index(request):
    if not request.session.get('is_login', None):
        return redirect('/login/')
    return render(request, 'login/index.html')

# 登陆
def login(request):
    if request.session.get('is_login', None):  # 不允许重复登录
        return redirect('/')
    if request.method == 'POST':
        login_form = forms.UserForm(request.POST)
        message = '请检查填写的内容！'
        if login_form.is_valid():
            username = login_form.cleaned_data.get('username')
            password = login_form.cleaned_data.get('password')

            try:
                user = models.User.objects.get(name=username)
            except :
                message = '用户不存在！'
                return render(request, 'login/login.html', locals())

            if not user.has_confirmed:
                message = '该用户还未经过邮件确认！'
                return render(request, 'login/login.html', locals())

            if user.password == hash_code(password):
                request.session['is_login'] = True
                request.session['user_id'] = user.id
                request.session['user_name'] = user.name
                return redirect('/')
            else:
                message = '密码不正确！'
                return render(request, 'login/login.html', locals())
        else:
            return render(request, 'login/login.html', locals())

    login_form = forms.UserForm()
    return render(request, 'login/login.html', locals())

# 注册
def register(request):
    if request.session.get('is_login', None):
        return redirect('/')
    if request.method == 'POST':
        register_form = forms.RegisterForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():
            username = register_form.cleaned_data.get('username')
            password1 = register_form.cleaned_data.get('password1')
            password2 = register_form.cleaned_data.get('password2')
            email = register_form.cleaned_data.get('email')
            sex = register_form.cleaned_data.get('sex')
            user_id = register_form.cleaned_data.get('user_id')

            if password1 != password2:
                message = '两次输入的密码不同！'
                return render(request, 'login/register.html', locals())
            else:
                same_name_user = models.User.objects.filter(name=username)
                if same_name_user:
                    message = '用户名已经存在'
                    return render(request, 'login/register.html', locals())
                same_email_user = models.User.objects.filter(email=email)
                if same_email_user:
                    message = '该邮箱已经被注册了！'
                    return render(request, 'login/register.html', locals())

                new_user = models.User()
                new_user.name = username
                new_user.password = hash_code(password1)
                new_user.email = email
                new_user.sex = sex
                new_user.user_id = user_id
                new_user.save()

                code = make_confirm_string(new_user)
                send_email(email, code)

                message = '请前往邮箱进行确认！'
                return render(request, 'login/confirm.html', locals())
        else:
            return render(request, 'login/register.html', locals())
    register_form = forms.RegisterForm()
    return render(request, 'login/register.html', locals())
# redirect一个路由转向另一个路由
# 登出
def logout(request):
    if not request.session.get('is_login', None):
        # 如果本来就未登录，也就没有登出一说
        return redirect("/login/")
    # request.session.flush()
    # 或者使用下面的方法
    del request.session['is_login']
    # del request.session['user_id']
    # del request.session['user_name']
    return redirect("/login/")

# 邮件发送
def send_email(email, code):
    
    from django.core.mail import EmailMultiAlternatives

    subject = '来自安徽建筑大学软件工程实验室的注册确认邮件'


    text_content = '''感谢注册安徽建筑大学软件工程实验室！\
                    如果你看到这条消息，说明你的邮箱服务器不提供HTML链接功能，请联系管理员！'''

    html_content = '''
                    <p>感谢注册<a href="http://{}/confirm/?code={}" target=blank>www.lab.sx.cn</a></p>
                    <p>请点击站点链接完成注册确认！</p>
                    <p>此链接有效期为{}天！</p>
                    '''.format('127.0.0.1:8000', code, settings.CONFIRM_DAYS)

    msg = EmailMultiAlternatives(subject, text_content, settings.EMAIL_HOST_USER, [email])
    msg.attach_alternative(html_content, "text/html")
    msg.send()

# 验证code确认码
def user_confirm(request):
    code = request.GET.get('code', None)
    message = ''
    try:
        confirm = models.ConfirmString.objects.get(code=code)
    except:
        message = '无效的确认请求!'
        return render(request, 'login/confirm.html', locals())

    c_time = confirm.c_time
    now = datetime.datetime.now()
    if now > c_time + datetime.timedelta(settings.CONFIRM_DAYS):
        confirm.user.delete()
        message = '您的邮件已经过期！请重新注册!'
        return render(request, 'login/confirm.html', locals())
    else:
        confirm.user.has_confirmed = True
        confirm.user.save()
        confirm.delete()
        message = '感谢确认，请使用账户登录！'
        return render(request, 'login/confirm.html', locals())


# 哈希加密
def hash_code(s,salt='LABweb'):
    h = hashlib.sha256()
    s += salt
    h.update(s.encode())
    return h.hexdigest()


# 创建确认码
def make_confirm_string(user):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    code = hash_code(user.name, now)
    models.ConfirmString.objects.create(code=code, user=user,)
    return code


# TODO:修改信息不应该是提交整个表单信息 若要修改部分信息怎么办？
# 解决方案是除图片信息外 其他用vuejs渲染修改信息
# 修改信息
# def change(request):
#     if request.method == 'POST':
#         change_form = forms.ChangeForm(request.POST,request.FILES)
#         if change_form.is_valid():
#             username = change_form.cleaned_data.get('username')
#             email = change_form.cleaned_data.get('email')
#             sex = change_form.cleaned_data.get('sex')
#             user_id = change_form.cleaned_data.get('user_id')
#             user_photo = change_form.cleaned_data.get('user_photo')
#             user_introduction = change_form.cleaned_data.get('user_introduction')
#             user_major = change_form.cleaned_data.get('user_major')

#             new_user = models.User.objects.get(name=username)
#             new_user.name = username
#             new_user.email = email
#             new_user.sex = sex
#             new_user.user_id = user_id
#             new_user.user_photo = user_photo
#             new_user.user_introduction = user_introduction
#             new_user.user_major = user_major
#             new_user.save()

#     return render(request,'login/change.html',locals())

# 以下是vuejs渲染修改信息
@api_view(['GET'])
def userchange(request):
    # if request.method == 'POST':
    username = request.GET['username']
    email = request.GET['email']
    user_id = request.GET['user_id']
    user_introduction = request.GET['user_introduction']
    user_major = request.GET['user_major']
    user_teamid = request.GET['user_teamid']

    # 根据提交的teamid获取对应的team对象,因为字段team_id是外键 只能绑定对象
    team = models.LabTeam.objects.get(team_name=user_teamid)

    # 获取当前用户
    name = request.session['user_name'] 

    user = models.User.objects.get(name=name)
    user.name = username
    user.email = email
    user.user_id = user_id
    user.user_introduction = user_introduction
    user.user_major = user_major
    user.team_id = team
    user.save()

    return HttpResponse('ok')

def change(request):
    pass
    return render(request,'login/change.html')

# 修改头像
def img(request):
    if request.method == 'POST':
        img=request.FILES.get('img')
        username = request.user.username
        print(img)
        user = models.User.objects.get(name=username)
        
        print(user.name)
        user.user_photo = img
        user.save()
        return redirect('../user/')


# 聊天室
clients = {}
# 服务器方法，允许接受ws请求
@accept_websocket
def chat(request):
    # 判断是不是ws请求
    if request.is_websocket():
        # 保存客户端的ws对象，以便给客户端发送消息,每个客户端分配一个唯一标识
        userid = request.session['user_name']
        clients[userid] = request.websocket
        # 判断是否有客户端发来消息，若有则进行处理，表示客户端与服务器建立链接成功
        while True:
            '''获取消息，线程会阻塞，
            他会等待客户端发来下一条消息,直到关闭后才会返回，当关闭时返回None'''
            message = request.websocket.wait()
            if not message:
                break
            else:
                msg = str(message, encoding="utf-8")
                print(msg)
                #1、发来test表示链接成功
                if msg == "test":
                    print("客户端链接成功："+userid)
                    #第一次进入，返回在线列表和他的id
                    request.websocket.send(json.dumps({"type": 0, "userlist": list(
                        clients.keys()), "userid": userid}).encode("'utf-8'"))
                    #更新所有人的userlist
                    for client in clients:
                        clients[client].send(json.dumps({"type": 0, "userlist": list(
                            clients.keys()), "user": None}).encode("'utf-8'"))
    #客户端关闭后从列表删除
    if userid in clients:
        del clients[userid]
        print(userid + "离线")
        # 更新所有人的userlist
        for client in clients:
            clients[client].send(
                json.dumps({"type": 0, "userlist": list(clients.keys()), "user": None}).encode("'utf-8'"))

#消息发送方法（局部禁用csrf）
@csrf_exempt
def msg_send(request):
    msg = request.POST.get("txt")
    useridto = request.POST.get("userto")
    useridfrom = request.POST.get("userfrom")
    type = request.POST.get("type")
    #发来{type:"2",msg:data,user:user},表示发送聊天信息，user为空表示群组消息，不为空表示要发送至的用户
    if type == "1":
        #群发
        for client in clients:
            clients[client].send(json.dumps(
                {"type": 1, "data": {"msg": msg, "user": useridfrom}}).encode('utf-8'))
    else:
        # 私聊，对方显示
        clients[useridto].send(json.dumps(
            {"type": 1, "data": {"msg": msg, "user": useridfrom}}).encode('utf-8'))
        # 私聊，自己显示
        clients[useridfrom].send(json.dumps(
            {"type": 1, "data": {"msg": msg, "user": useridfrom}}).encode('utf-8'))
    return HttpResponse(json.dumps({"msg": "success"}))
