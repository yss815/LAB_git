from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.decorators import api_view

from login.models import *
# 用户
class Users(serializers.ModelSerializer):
    class Meta:
        model = User
        depth = 1
        fields = '__all__'

@api_view(['GET'])
def userdata(request):
    username = request.user.username
    # print(username)
    user = User.objects.filter(name=username)
    userdata = Users(user,many=True)

    return Response({'user':userdata.data})