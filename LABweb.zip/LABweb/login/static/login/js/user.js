var app = new Vue({
    el:'#userinf',
    data:{
        userdata:'',
        userUI:false,
        username:'',
        email:'',
        user_introduction:'',
        user_major:'',
        user_id:'',
        user_teamid:'',
    },
    // 执行循序依次，但回调函数总是再最后执行
    // 因此getuser拿不到在getsession中回调得到的name
    mounted(){
        this.getuser()
    },
    methods:{
        getuser:function(){
            var self = this
            reqwest({
                url:'userdata/',
                method:'get',
                type:'json',
                success:function(data){
                    console.log(data.user)
                    self.userdata = data.user
                    self.username = self.userdata[0].name
                    self.email = self.userdata[0].email
                    self.user_introduction = self.userdata[0].user_introduction
                    self.user_major = self.userdata[0].user_major
                    self.user_id = self.userdata[0].user_id
                    self.user_teamid = self.userdata[0].user_teamid.team_name
                }
            })
        },
        userchange:function(){
            var self = this
            reqwest({
                url:'userchange/',
                method:'get',
                type:'json',
                data:{
                    username:self.username,
                    email:self.email,
                    user_introduction:self.user_introduction,
                    user_id:self.user_id,
                    user_major:self.user_major,
                    user_teamid:self.user_teamid
                },
                success: function(){
                    window.location.href = '/user'
                }
            })
            window.location.href = '/user'
        },
        showUserUI:function(){
            this.userUI = !this.userUI
        },
        toindex:function(){
            window.location.href = '../'
        }
    }
})