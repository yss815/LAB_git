var app = new Vue({
    el:'#index',
    data:{
        title:''
    },
    mounted(){
        this.gettitle()
    },
    methods:{
        gettitle:function(){
            var self = this
            reqwest({
                url:'news/outnews/',
                method:'get',
                type:'json',
                success: function(data) {
                    console.log(data)
                    self.title=data
                },
                error:function(err){
                    console.log(err)
                }
            })
        },
        touser:function(){
            window.location.href = '/user'
        },
        topost:function(){
            window.location.href = 'news/post'
        },
        topractice: function () {
            window.location.href = '/paper/practice'
        },
        tozhaoxin: function () {
            window.location.href = '/paper/zhaoxin'
        },

    }
})