from django.db import models

# Create your models here.


# 分组表
class LabTeam(models.Model):
    team_id = models.IntegerField(primary_key=True)
    team_name = models.CharField( default='',blank=True,max_length=50,unique=True)
    team_captain = models.CharField(default='',blank=True, max_length=50)
     
    def __str__(self):
        return self.team_name
    class Meta:
        verbose_name = '分组'
        verbose_name_plural = '分组'


# 总用户
class User(models.Model):

    gender = (
        ('male', '男'),
        ('female', '女')
    )

    name = models.CharField(max_length=128, unique=True)
    password = models.CharField(max_length=256)
    email = models.EmailField(unique=True)
    sex = models.CharField(max_length=32, choices=gender, default='男')
    c_time = models.DateField(auto_now_add=True)
    has_confirmed = models.BooleanField(default=False)

    user_photo = models.ImageField(blank=True,null=True)
    user_introduction = models.TextField(blank=True,null=True)
    user_major = models.CharField(default='',blank=True,max_length=20)
    user_teamid = models.ForeignKey(LabTeam, on_delete=models.CASCADE,to_field='team_name',blank=True,null=True)
    user_access = models.IntegerField(default='2')
    user_id = models.CharField(max_length=128,blank=True,null=True)
    

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['-c_time']
        verbose_name = '用户'
        verbose_name_plural = '用户'

# 注册时的确认码
class ConfirmString(models.Model):
    code = models.CharField(max_length=256)
    user = models.OneToOneField('User', on_delete=models.CASCADE)
    c_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.name + self.code

    class Meta:
        ordering = ['-c_time']
        verbose_name = '确认码'
        verbose_name_plural = '确认码'



# 三种用户表再关联用户主表
# 老师用户
# class LabUserteacher(models.Model):
#     teacher_id = models.OneToOneField( User, on_delete=models.CASCADE)
#     teacher_name = models.CharField( max_length=3,blank=True,null=True)
#     teacher_photo = models.ImageField(blank=True,null=True)
#     teacher_introduction = models.TextField(blank=True,null=True)
#     teacher_access = models.IntegerField(default='1')
#     teacher_postion = models.CharField(default='',blank=True,max_length=20)
#     teacher_teamid = models.ForeignKey(LabTeam, on_delete=models.CASCADE,to_field='team_name',blank=True,null=True)
    
#     def __str__(self):
#         return self.teacher_id.name
#     class Meta:
#         verbose_name = '老师'
#         verbose_name_plural = '老师'
        
# 学生用户
# class LabUserstudent(models.Model):
#     student_id = models.OneToOneField( User, on_delete=models.CASCADE)
#     student_name = models.CharField(max_length=3,blank=True,null=True)
#     student_photo = models.ImageField(blank=True,null=True)
#     student_introduction = models.TextField(blank=True,null=True)
#     student_major = models.CharField(default='',blank=True,max_length=20)
#     student_teamid = models.ForeignKey(LabTeam, on_delete=models.CASCADE,to_field='team_name',blank=True,null=True)
#     student_access = models.IntegerField(default='2')
    
#     def __str__(self):
#         return self.student_id.name
#     class Meta:
#         verbose_name = '学生'
#         verbose_name_plural = '学生'
    

class Img(models.Model):
    img = models.ImageField(blank=True,null=True)
    
    class Meta:
        verbose_name = 'Img'
        verbose_name_plural = 'Imgs'
