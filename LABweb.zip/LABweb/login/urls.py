from django.urls import path

from . import views,apis

urlpatterns = [
    path('', views.index),
    path('login/', views.login),
    path('register/', views.register),
    path('logout/', views.logout),
    path('confirm/',views.user_confirm),
    # path('change/',views.change),
    path('user/',views.user),
    # 调取用户的信息返回前端
    path('user/userdata/',apis.userdata),
    path('user/userchange/',views.userchange),
    path('change/',views.change),
    path('img/',views.img),
    # 聊天
    path('chat/', views.chat),
    path('msg_send/', views.msg_send),


]
