from django.shortcuts import render
# from rest_framework.response import Response
from django.http import JsonResponse
import requests,json
from rest_framework.decorators import api_view
from . import models
from login.models import User
from django.shortcuts import redirect
# Create your views here.

# 因跨域问题 js无法直接获取外部数据 在此中转外部api
def getoutnews(request):
    url = "http://v.juhe.cn/toutiao/index?type=top&key=7a213728f5d82ddc0adb534b2eeb1196"
    r = requests.get(url)
    data = r.json()

    if data['error_code'] == 0:
        result = data['result']
        s = result['data'][0:6]
        return JsonResponse(s,safe=False)
    else:
        return JsonResponse(data)

def post(request):
    pass
    return render(request,'news/post.html')

@api_view(['POST'])
def fabupost(request):
    if request.method == 'POST':
        name = request.POST['name']
        message = request.POST['message']
        content = {
            'name':name,
            'message':message
        }
        user = User.objects.get(name=name)
        post = models.LabInformation()
        post.userID = user
        post.information_content = message
        post.save()
        
    return render(request,'news/post.html',content)

def gain(request):
    pass
    return render(request,'news/gain.html')

