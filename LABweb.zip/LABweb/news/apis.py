from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.decorators import api_view

from news.models import *


# 新闻
class LabInNewsData(serializers.ModelSerializer):
    class Meta:
        model = LabInNews
        fields = '__all__'

@api_view(['GET'])
def newsdata(request):
    news = LabInNews.objects.all()
    newsdata = LabInNewsData(news,many=True)

    return  Response({'new':newsdata.data})

# 动态
class LabInformations(serializers.ModelSerializer):
    class Meta:
        model = LabInformation
        fields = '__all__'

@api_view(['GET'])
def infdata(request):
    inf = LabInformation.objects.all()
    infdata = LabInformations(inf,many=True)

    return Response({'inf':infdata.data})

# banner
class Banners(serializers.ModelSerializer):
    class Meta:
        model = Banner
        fields = '__all__'

@api_view(['GET'])
def banner(request):
    banner = Banner.objects.all()
    bannerData = Banners(banner,many=True)

    return Response({'banner':bannerData.data})

# 成果
class Gains(serializers.ModelSerializer):
    class Meta:
        mdoel = LabGain
        fields = '__all__'

@api_view(['GET'])
def gain(request):
    gain = LabGain.objetcs.all()
    gaindata = Gains(gain,many=True)

    return Response({'gain':gaindata.data})

# 比赛
class Competes(serializers.ModelSerializer):
    class Meta:
        model = LabCompete
        fields = '__all__'

@api_view(['GET'])
def compete(request):
    compete = LabCompete.objetcs.all()
    competedata = Competes(compete,many=True)

    return Response({'compete':competedata.data})