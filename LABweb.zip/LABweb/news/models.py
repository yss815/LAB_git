from django.db import models
from django.utils import timezone
# Create your models here.

# 实验室新闻表
class LabInNews(models.Model):
    news_title = models.CharField( max_length=50)
    news_content = models.TextField()
    news_date = models.DateField( auto_now=False, auto_now_add=False)
    news_see = models.IntegerField(null=True)
    news_comment = models.TextField(max_length=1024)

    class Meta:
        ordering = ["-news_date"]
        verbose_name = '实验室新闻'
        verbose_name_plural = '实验室新闻'

    def __str__(self):
        return self.news_title

# 动态表
class LabInformation(models.Model):
    userID = models.ForeignKey("login.User", on_delete=models.CASCADE,to_field="name")
    information_content = models.TextField(default='')
    information_date = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.userID.name
    class Meta:
        verbose_name = '实验室动态'
        verbose_name_plural = '实验室动态'
        ordering = ['-information_date']

# banner
class Banner(models.Model):
    img = models.ImageField(blank=True,null=True)

    def __str__(self):
        return self.id
    class Meta:
        verbose_name = '轮播图'
        verbose_name_plural = '轮播图'
    
# 成果
class LabGain(models.Model):
    gain_user = models.ForeignKey("login.User", on_delete=models.CASCADE)
    gain_title = models.CharField( max_length=50)
    gain_decb = models.TextField(blank=True,null=True)
    gain_photo = models.ImageField(blank=True,null=True)
    gain_see = models.IntegerField(blank=True,null=True)
    gain_getdate = models.DateField( auto_now=False, auto_now_add=False,null=True)

    class Meta:
        ordering = ['-gain_getdate']
        verbose_name = '成果'
        verbose_name_plural = '成果'
    def __str__(self):
        return self.gain_title
        
# 比赛
class LabCompete(models.Model):
    compete_name = models.CharField( max_length=50)
    compete_desc = models.CharField( max_length=50)
    compete_type = models.CharField( max_length=20)
    compete_date = models.DateField( auto_now=False, auto_now_add=False)

    class Meta:
        ordering = ['-compete_date']
        verbose_name = '比赛'
        verbose_name_plural = '比赛'
    def __str__(self):
        return self.compete_name
