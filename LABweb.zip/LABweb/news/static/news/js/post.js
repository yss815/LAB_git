var app = new Vue({
    el:'#post',
    data:{
        // 帖子表单提交绑定data
        name:'',
        message:'',
        // 渲染帖子绑定data
        post:[]
    },
    mounted(){
        this.getpost()
        console.log('1111')
    },
    methods:{
        fabu:function(){
            var self = this
            reqwest({
                url:'/news/fabupost/',
                method:'post',
                type:'json',
                headers:{
                    "X-CSRFTOKEN":csrftoken
                },
                data:{
                    name:self.name,
                    message:self.message
                },
                // success是回调函数
                success:function(data){
                    
                },
                error:function(err){
                    console.log(err)
                }
            })
            window.location.href = '/news/post/'
        },
        getpost:function(){
            var self = this
            reqwest({
                url:'/news/infdata/',
                method:'get',
                type:'json',
                success: function(data) {
                    console.log(data)
                    self.post = data.inf
                }
            })
        }
    }
})