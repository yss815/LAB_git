var app = new Vue({
    el:'#index',
    data:{
        title:''
    },
    mounted(){
        this.gettitle()
    },
    methods:{
        gettitle:function(){
            var self = this
            reqwest({
                url:'outnews/',
                method:'get',
                type:'json',
                success: function(data) {
                    console.log(data)
                    self.title=data
                },
                error:function(err){
                    console.log(err)
                }
            })
        }
    }
})