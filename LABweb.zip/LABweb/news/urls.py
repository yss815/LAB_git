from django.urls import path

from . import views,apis

urlpatterns = [
    path('newsdata/',apis.newsdata),
    path('infdata/',apis.infdata),
    path('banner/',apis.banner),
    path('gian/',apis.gain),
    path('compete/',apis.compete),
    path('outnews/',views.getoutnews),
    path('post/',views.post),
    path('fabupost/',views.fabupost),
    path('gain/',views.gain)
]