from django.contrib import admin

# Register your models here.

from . import models

admin.site.register(models.LabInNews)
admin.site.register(models.LabInformation)
admin.site.register(models.Banner)
admin.site.register(models.LabGain),
admin.site.register(models.LabCompete)
