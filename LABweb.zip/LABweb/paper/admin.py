from django.contrib import admin
from . import models

# Register your models here.

admin.site.register(models.LabPraProb1)
admin.site.register(models.LabPraProb2)
admin.site.register(models.LabPraProb3)
admin.site.register(models.LabPraProbD1)
admin.site.register(models.LabPraProbD2)
admin.site.register(models.LabPraProbD3)
admin.site.register(models.LabPraProbP1)
admin.site.register(models.LabPraProbP2)
admin.site.register(models.LabPraProbP3)
admin.site.register(models.LabPraProbK1)
admin.site.register(models.LabPraProbK2)
admin.site.register(models.LabPraProbK3)
