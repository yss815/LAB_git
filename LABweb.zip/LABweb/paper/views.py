from django.shortcuts import render
from rest_framework.decorators import api_view

# Create your views here.
# 点击跳转到练习模块
def practice(request):
    pass
    return render(request, 'paper/practice.html')

# 点击跳转到招新模块
def zhaoxin(request):
    pass
    return render(request, 'paper/zhaoxin.html')

# 选择难度跳转对应试题库
def pratest(request):
    pass
    return render(request, 'paper/pratest.html')


