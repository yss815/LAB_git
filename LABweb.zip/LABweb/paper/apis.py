from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.decorators import api_view

from paper.models import *
import random
# 练习模块的序列化
# 单选题的序列化


class LabPraProb1s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProb1
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)


class LabPraProb2s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProb2
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)


class LabPraProb3s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProb3
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)

# 多选题的序列化


class LabPraProbD1s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbD1
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)


class LabPraProbD2s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbD2
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)


class LabPraProbD3s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbD3
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)

# 判断题的序列化


class LabPraProbP1s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbP1
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)


class LabPraProbP2s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbP2
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)


class LabPraProbP3s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbP3
        fields = ("prob_body", "prob_option_a", "prob_option_b",
                  "prob_option_c", "prob_option_d",)

# 填空题的序列化


class LabPraProbK1s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbK1
        fields = ["prob_body"]


class LabPraProbK2s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbK2
        fields = ["prob_body"]


class LabPraProbK3s(serializers.ModelSerializer):
    class Meta:
        model = LabPraProbK3
        fields = ["prob_body"]
Type = int()
level_ID = str()
Num = int()
Selected1 = str()
# 获取level_id或者专项演练的对应id
@api_view(['GET'])
def getlevel_id(request):
    level_id = request.GET['level_id']
    global level_ID
    global Type
    Type = 1
    level_ID = level_id
    return Response('ok')

# 获取专项演练中的题量值
@api_view(['GET'])
def getnum(request):
    num = request.GET['num']
    num1 = int(num)
    global Num
    global Type
    Type = 2
    Num = num1
    return Response('ok')

# 获取专项演练中的题型值
@api_view(['GET'])
def getselect(request):
    selected = request.GET['selected']
    global Selected1
    global Type
    Type = 3
    Selected1 = selected
    return Response('ok')

# 获取专项演练中的题型值和题数量
@api_view(['GET'])
def getadd(request):
    selected = request.GET['selected']
    num2 = request.GET['num2']
    num1 = int(num2)
    global Selected1
    global Type
    global Num
    Type = 4
    Num = num1
    Selected1 = selected
    return Response('ok')

# 根据难度调取对应试题(包含单选，多选，判断题，填空题)
@api_view(['GET'])
def prapaperID(request):
    # 根据难度自动生成试题
    if Type == 1:
        # s1,s2,s3代表每个难度应调出的题数
        if(level_ID == '1'):
            s1, s2, s3 = 30, 10, 0
        elif(level_ID == '2'):
            s1, s2, s3 = 20, 10, 4
        elif(level_ID == '3'):
            s1, s2, s3 = 10, 10, 8

        # 难度为1
        # 单选题
        question1 = LabPraProb1.objects.filter(
            id__in=[random.random()*51 for _ in range(s1)])
        question1Data = LabPraProb1s(question1, many=True)
        # 多选题
        questiond1 = LabPraProbD1.objects.filter(
            id__in=[random.random()*40 for _ in range(s1)])
        questiond1Data = LabPraProbD1s(questiond1, many=True)
        # 判断题
        questionp1 = LabPraProbP1.objects.filter(
            id__in=[random.random()*50 for _ in range(s1)])
        questionp1Data = LabPraProbP1s(questionp1, many=True)
        # 填空题
        questionk1 = LabPraProbK1.objects.filter(
            id__in=[random.random()*50 for _ in range(s1)])
        questionk1Data = LabPraProbK1s(questionk1, many=True)

        # 难度为2
        # 单选题
        question2 = LabPraProb2.objects.filter(
            id__in=[random.random()*40 for _ in range(s2)])
        question2Data = LabPraProb2s(question2, many=True)
        # 多选题
        questiond2 = LabPraProbD2.objects.filter(
            id__in=[random.random()*40 for _ in range(s2)])
        questiond2Data = LabPraProbD2s(questiond2, many=True)
        # 判断题
        questionp2 = LabPraProbP2.objects.filter(
            id__in=[random.random()*40 for _ in range(s2)])
        questionp2Data = LabPraProbP2s(questionp2, many=True)
        # 填空题
        questionk2 = LabPraProbK2.objects.filter(
            id__in=[random.random()*40 for _ in range(s2)])
        questionk2Data = LabPraProbK2s(questionk2, many=True)

        # 难度为3
        # 单选题
        question3 = LabPraProb3.objects.filter(
            id__in=[random.random()*20 for _ in range(s3)])
        question3Data = LabPraProb3s(question3, many=True)
        # 多选题
        questiond3 = LabPraProbD3.objects.filter(
            id__in=[random.random()*40 for _ in range(s3)])
        questiond3Data = LabPraProbD3s(questiond3, many=True)
        # 判断题
        questionp3 = LabPraProbP3.objects.filter(
            id__in=[random.random()*40 for _ in range(s3)])
        questionp3Data = LabPraProbP3s(questionp3, many=True)
        # 填空题
        questionk3 = LabPraProbK3.objects.filter(
            id__in=[random.random()*40 for _ in range(s3)])
        questionk3Data = LabPraProbK3s(questionk3, many=True)

        return Response({'paper': {'question1': question1Data.data, 'question2': question2Data.data, 'question3': question3Data.data, 'questiond1': questiond1Data.data, 'questiond2': questiond2Data.data, 'questiond3': questiond3Data.data, 'questionp1': questionp1Data.data, 'questionp2': questionp2Data.data, 'questionp3': questionp3Data.data, 'questionk1': questionk1Data.data, 'questionk2': questionk2Data.data, 'questionk3': questionk3Data.data}})
    # 专项演练中的根据题量生成试题
    elif Type == 2:
        s1 = int(Num/2)
        s2 = int(Num/3)
        s3 = int(Num-s1-s2)
        # print(s1,s2,s3)
        # 难度为1
        # 单选题
        question1 = LabPraProb1.objects.filter(
            id__in=[random.random()*51 for _ in range(s1)])
        question1Data = LabPraProb1s(question1, many=True)
        # 多选题
        questiond1 = LabPraProbD1.objects.filter(
            id__in=[random.random()*40 for _ in range(s1)])
        questiond1Data = LabPraProbD1s(questiond1, many=True)
        # 判断题
        questionp1 = LabPraProbP1.objects.filter(
            id__in=[random.random()*50 for _ in range(s1)])
        questionp1Data = LabPraProbP1s(questionp1, many=True)
        # 填空题
        questionk1 = LabPraProbK1.objects.filter(
            id__in=[random.random()*50 for _ in range(s1)])
        questionk1Data = LabPraProbK1s(questionk1, many=True)

        # 难度为2
        # 单选题
        question2 = LabPraProb2.objects.filter(
            id__in=[random.random()*40 for _ in range(s2)])
        question2Data = LabPraProb2s(question2, many=True)
        # 多选题
        questiond2 = LabPraProbD2.objects.filter(
            id__in=[random.random()*40 for _ in range(s2)])
        questiond2Data = LabPraProbD2s(questiond2, many=True)
        # 判断题
        questionp2 = LabPraProbP2.objects.filter(
            id__in=[random.random()*40 for _ in range(s2)])
        questionp2Data = LabPraProbP2s(questionp2, many=True)
        # 填空题
        questionk2 = LabPraProbK2.objects.filter(
            id__in=[random.random()*40 for _ in range(s2)])
        questionk2Data = LabPraProbK2s(questionk2, many=True)

        # 难度为3
        # 单选题
        question3 = LabPraProb3.objects.filter(
            id__in=[random.random()*20 for _ in range(s3)])
        question3Data = LabPraProb3s(question3, many=True)
        # 多选题
        questiond3 = LabPraProbD3.objects.filter(
            id__in=[random.random()*40 for _ in range(s3)])
        questiond3Data = LabPraProbD3s(questiond3, many=True)
        # 判断题
        questionp3 = LabPraProbP3.objects.filter(
            id__in=[random.random()*40 for _ in range(s3)])
        questionp3Data = LabPraProbP3s(questionp3, many=True)
        # 填空题
        questionk3 = LabPraProbK3.objects.filter(
            id__in=[random.random()*40 for _ in range(s3)])
        questionk3Data = LabPraProbK3s(questionk3, many=True)

        return Response({'paper': {'question1': question1Data.data, 'question2': question2Data.data, 'question3': question3Data.data, 'questiond1': questiond1Data.data, 'questiond2': questiond2Data.data, 'questiond3': questiond3Data.data, 'questionp1': questionp1Data.data, 'questionp2': questionp2Data.data, 'questionp3': questionp3Data.data, 'questionk1': questionk1Data.data, 'questionk2': questionk2Data.data, 'questionk3': questionk3Data.data}})
    # 专项演练中根据题型生成试题
    elif Type == 3:
        s1 = 20 
        s2 = 15 
        s3 = 15
        if Selected1 == '1':
            # 单选
            question1 = LabPraProb1.objects.filter(
                id__in=[random.random()*51 for _ in range(s1)])
            question1Data = LabPraProb1s(question1, many=True)
            question2 = LabPraProb2.objects.filter(
                id__in=[random.random()*40 for _ in range(s2)])
            question2Data = LabPraProb2s(question2, many=True)
            question3 = LabPraProb3.objects.filter(
                id__in=[random.random()*20 for _ in range(s3)])
            question3Data = LabPraProb3s(question3, many=True)
            return Response({'paper': {'question1': question1Data.data, 'question2': question2Data.data, 'question3': question3Data.data}})
        elif Selected1 == '2':
            # 多选
            questiond1 = LabPraProbD1.objects.filter(
                id__in=[random.random()*40 for _ in range(s1)])
            questiond1Data = LabPraProbD1s(questiond1, many=True)
            questiond2 = LabPraProbD2.objects.filter(
                id__in=[random.random()*40 for _ in range(s2)])
            questiond2Data = LabPraProbD2s(questiond2, many=True)
            questiond3 = LabPraProbD3.objects.filter(
                id__in=[random.random()*40 for _ in range(s3)])
            questiond3Data = LabPraProbD3s(questiond3, many=True)
            return Response({'paper': {'questiond1': questiond1Data.data, 'questiond2': questiond2Data.data, 'questiond3': questiond3Data.data}})
        elif Selected1 == '3':
            questionp1 = LabPraProbP1.objects.filter(
                id__in=[random.random()*50 for _ in range(s1)])
            questionp1Data = LabPraProbP1s(questionp1, many=True)
            questionp2 = LabPraProbP2.objects.filter(
                id__in=[random.random()*40 for _ in range(s2)])
            questionp2Data = LabPraProbP2s(questionp2, many=True)
            questionp3 = LabPraProbP3.objects.filter(
                id__in=[random.random()*40 for _ in range(s3)])
            questionp3Data = LabPraProbP3s(questionp3, many=True)
            return Response({'paper': {'questionp1': questionp1Data.data, 'questionp2': questionp2Data.data, 'questionp3': questionp3Data.data}})
        elif Selected1 == '4':
            questionk1 = LabPraProbK1.objects.filter(
                id__in=[random.random()*50 for _ in range(s1)])
            questionk1Data = LabPraProbK1s(questionk1, many=True)
            questionk2 = LabPraProbK2.objects.filter(
                id__in=[random.random()*40 for _ in range(s2)])
            questionk2Data = LabPraProbK2s(questionk2, many=True)
            questionk3 = LabPraProbK3.objects.filter(
                id__in=[random.random()*40 for _ in range(s3)])
            questionk3Data = LabPraProbK3s(questionk3, many=True)
            return Response({'paper': {'questionk1': questionk1Data.data, 'questionk2': questionk2Data.data, 'questionk3': questionk3Data.data}})
    # 专项演练中根据题量题型生成试题
    elif Type == 4:
        s1 = int(Num/2)
        s2 = int(Num/3)
        s3 = int(Num-s1-s2)
        if Selected1 == '1':
            # 单选
            question1 = LabPraProb1.objects.filter(
                id__in=[random.random()*51 for _ in range(s1)])
            question1Data = LabPraProb1s(question1, many=True)
            question2 = LabPraProb2.objects.filter(
                id__in=[random.random()*40 for _ in range(s2)])
            question2Data = LabPraProb2s(question2, many=True)
            question3 = LabPraProb3.objects.filter(
                id__in=[random.random()*20 for _ in range(s3)])
            question3Data = LabPraProb3s(question3, many=True)
            return Response({'paper': {'question1': question1Data.data, 'question2': question2Data.data, 'question3': question3Data.data}})
        elif Selected1 == '2':
            # 多选
            questiond1 = LabPraProbD1.objects.filter(
                id__in=[random.random()*40 for _ in range(s1)])
            questiond1Data = LabPraProbD1s(questiond1, many=True)
            questiond2 = LabPraProbD2.objects.filter(
                id__in=[random.random()*40 for _ in range(s2)])
            questiond2Data = LabPraProbD2s(questiond2, many=True)
            questiond3 = LabPraProbD3.objects.filter(
                id__in=[random.random()*40 for _ in range(s3)])
            questiond3Data = LabPraProbD3s(questiond3, many=True)
            return Response({'paper': {'questiond1': questiond1Data.data, 'questiond2': questiond2Data.data, 'questiond3': questiond3Data.data}})
        elif Selected1 == '3':
            # 判断
            questionp1 = LabPraProbP1.objects.filter(
                id__in=[random.random()*50 for _ in range(s1)])
            questionp1Data = LabPraProbP1s(questionp1, many=True)
            questionp2 = LabPraProbP2.objects.filter(
                id__in=[random.random()*40 for _ in range(s2)])
            questionp2Data = LabPraProbP2s(questionp2, many=True)
            questionp3 = LabPraProbP3.objects.filter(
                id__in=[random.random()*40 for _ in range(s3)])
            questionp3Data = LabPraProbP3s(questionp3, many=True)
            return Response({'paper': {'questionp1': questionp1Data.data, 'questionp2': questionp2Data.data, 'questionp3': questionp3Data.data}})
        elif Selected1 == '4':
            # 填空题
            questionk1 = LabPraProbK1.objects.filter(
                id__in=[random.random()*50 for _ in range(s1)])
            questionk1Data = LabPraProbK1s(questionk1, many=True)
            questionk2 = LabPraProbK2.objects.filter(
                id__in=[random.random()*40 for _ in range(s2)])
            questionk2Data = LabPraProbK2s(questionk2, many=True)
            questionk3 = LabPraProbK3.objects.filter(
                id__in=[random.random()*40 for _ in range(s3)])
            questionk3Data = LabPraProbK3s(questionk3, many=True)
            return Response({'paper': {'questionk1': questionk1Data.data, 'questionk2': questionk2Data.data, 'questionk3': questionk3Data.data}})
