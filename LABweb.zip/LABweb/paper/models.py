from django.db import models

# Create your models here.

# 练习试题库
# 单选题难度为1
class LabPraProb1(models.Model):
    prob_difficult = models.IntegerField(default='1')
    prob_body = models.TextField(max_length=2048, null=True, default='单选题难度为1')
    prob_option_a = models.CharField(max_length=1024, null=True,default='A')
    prob_option_b = models.CharField(max_length=1024, null=True, default='B')
    prob_option_c = models.CharField(max_length=1024, null=True, default='C')
    prob_option_d = models.CharField(max_length=1024, null=True, default='D')
    prob_right = models.CharField(max_length=50, null=True, default='A')
    prob_score = models.IntegerField(default='2')
    prob_type = models.CharField(default='单选', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '单选难度1'
        verbose_name_plural = '单选难度1'


# 单选题难度为2
class LabPraProb2(models.Model):
    prob_difficult = models.IntegerField(default='2')
    prob_body = models.TextField(max_length=2048, default='单选题难度为2')
    prob_option_a = models.CharField(max_length=1024, default='A')
    prob_option_b = models.CharField(max_length=1024, default='B')
    prob_option_c = models.CharField(max_length=1024, default='C')
    prob_option_d = models.CharField(max_length=1024, default='D')
    prob_right = models.CharField(max_length=50, null=True, default='A')
    prob_score = models.IntegerField(default='4')
    prob_type = models.CharField(default='单选', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '单选难度2'
        verbose_name_plural = '单选难度2'


# 单选题难度为3
class LabPraProb3(models.Model):
    prob_difficult = models.IntegerField(default='3')
    prob_body = models.TextField(max_length=2048, default='单选题难度为3')
    prob_option_a = models.CharField(max_length=1024, default='A')
    prob_option_b = models.CharField(max_length=1024, default='B')
    prob_option_c = models.CharField(max_length=1024, default='C')
    prob_option_d = models.CharField(max_length=1024, default='D')
    prob_right = models.CharField(max_length=50, null=True, default='A')
    prob_score = models.IntegerField(default='5')
    prob_type = models.CharField(default='单选', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '单选难度3'
        verbose_name_plural = '单选难度3'

# 多选题难度为1
class LabPraProbD1(models.Model):
    prob_difficult = models.IntegerField(default='1')
    prob_body = models.TextField(max_length=2048, null=True, default='多选题难度为1')
    prob_option_a = models.CharField(max_length=1024, null=True, default='A')
    prob_option_b = models.CharField(max_length=1024, null=True, default='B')
    prob_option_c = models.CharField(max_length=1024, null=True, default='C')
    prob_option_d = models.CharField(max_length=1024, null=True, default='D')
    prob_right = models.CharField(max_length=50, null=True, default='A')
    prob_score = models.IntegerField(default='2')
    prob_type = models.CharField(default='多选', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '多选难度1'
        verbose_name_plural = '多选难度1'


# 多选题难度为2
class LabPraProbD2(models.Model):
    prob_difficult = models.IntegerField(default='2')
    prob_body = models.TextField(max_length=2048, default='多选题的难度为2')
    prob_option_a = models.CharField(default='A', max_length=1024)
    prob_option_b = models.CharField(default='B', max_length=1024)
    prob_option_c = models.CharField(default='C', max_length=1024)
    prob_option_d = models.CharField(default='D', max_length=1024)
    prob_right = models.CharField(default='ABC', max_length=50, null=True)
    prob_score = models.IntegerField(default='4')
    prob_type = models.CharField(default='多选', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '多选难度2'
        verbose_name_plural = '多选难度2'


# 多选题难度为3
class LabPraProbD3(models.Model):
    prob_difficult = models.IntegerField(default='3')
    prob_body = models.TextField(max_length=2048, default='多选题的难度为3')
    prob_option_a = models.CharField(max_length=1024, default='A')
    prob_option_b = models.CharField(max_length=1024, default='B')
    prob_option_c = models.CharField(max_length=1024, default='C')
    prob_option_d = models.CharField(max_length=1024, default='D')
    prob_right = models.CharField(default='AD', max_length=50, null=True)
    prob_score = models.IntegerField(default='6')
    prob_type = models.CharField(default='多选', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '多选难度3'
        verbose_name_plural = '多选难度3'

# 判断题难度为1
class LabPraProbP1(models.Model):
    prob_difficult = models.IntegerField(default='1')
    prob_body = models.TextField(max_length=2048, null=True, default='判断题难度为1')
    prob_option_a = models.CharField(max_length=1024, null=True, default='A')
    prob_option_b = models.CharField(max_length=1024, null=True, default='B')
    prob_option_c = models.CharField(max_length=1024, null=True, default='C')
    prob_option_d = models.CharField(max_length=1024, null=True, default='D')
    prob_right = models.CharField(default='A', max_length=50, null=True)
    prob_score = models.IntegerField(default='1')
    prob_type = models.CharField(default='判断', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '判断难度1'
        verbose_name_plural = '判断难度1'


# 判断题难度为2
class LabPraProbP2(models.Model):
    prob_difficult = models.IntegerField(default='2')
    prob_body = models.TextField(max_length=2048, default='判断题难度为2')
    prob_option_a = models.CharField(max_length=1024, default='A')
    prob_option_b = models.CharField(max_length=1024, default='B')
    prob_option_c = models.CharField(max_length=1024, default='C')
    prob_option_d = models.CharField(max_length=1024, default='D')
    prob_right = models.CharField(default='B', max_length=50, null=True)
    prob_score = models.IntegerField(default='2')
    prob_type = models.CharField(default='判断', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '判断难度2'
        verbose_name_plural = '判断难度2'


# 判断题难度为3
class LabPraProbP3(models.Model):
    prob_difficult = models.IntegerField(default='3')
    prob_body = models.TextField(max_length=2048, default='判断题难度为3')
    prob_option_a = models.CharField(max_length=1024, default='A')
    prob_option_b = models.CharField(max_length=1024, default='B')
    prob_option_c = models.CharField(max_length=1024, default='C')
    prob_option_d = models.CharField(max_length=1024, default='D')
    prob_right = models.CharField(default='C', max_length=50, null=True)
    prob_score = models.IntegerField(default='4')
    prob_type = models.CharField(default='判断', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '判断难度3'
        verbose_name_plural = '判断难度3'


# 填空题难度为1
class LabPraProbK1(models.Model):
    prob_difficult = models.IntegerField(default='1')
    prob_body = models.TextField(max_length=2048, null=True, default='填空题难度为1')
    prob_right = models.CharField(max_length=50, null=True, default='在此输入答案')
    prob_score = models.IntegerField(default='1')
    prob_type = models.CharField(default='填空', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '填空难度1'
        verbose_name_plural = '填空难度1'

# 填空题难度为2
class LabPraProbK2(models.Model):
    prob_difficult = models.IntegerField(default='2')
    prob_body = models.TextField(max_length=2048, default='填空题难度为2')
    prob_right = models.CharField(max_length=50, null=True, default='在此输入答案')
    prob_score = models.IntegerField(default='2')
    prob_type = models.CharField(default='填空', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '填空难度2'
        verbose_name_plural = '填空难度2'


# 填空题难度为3
class LabPraProbK3(models.Model):
    prob_difficult = models.IntegerField(default='3')
    prob_body = models.TextField(max_length=2048, default='填空题难度为3')
    prob_right = models.CharField(max_length=50, null=True, default='在此输入答案')
    prob_score = models.IntegerField(default='4')
    prob_type = models.CharField(default='填空', max_length=50)

    def __int__(self):
        return self.prob_difficult

    class Meta:
        verbose_name = '填空难度3'
        verbose_name_plural = '填空难度3'
