from django.urls import path

from . import views, apis

urlpatterns = [
    path('practice/',views.practice),
    path('zhaoxin/',views.zhaoxin),
    # 跳转生成试卷
    path('pratest/',views.pratest),
    # 根据难度调取试题
    path('getlevel_id/',apis.getlevel_id),
    path('getpradata/',apis.prapaperID),
    # 专项演练根据题量调取试题
    path('getnum/',apis.getnum),
    path('getselect/',apis.getselect),
    path('getadd/',apis.getadd),
]
