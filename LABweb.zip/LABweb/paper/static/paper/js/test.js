var app = new Vue({
    el: '#test',
    data: {
        paperdata:[]
    },
    mounted() {
        this.getdata()
    },
    methods: {
        getdata:function(){
            var self = this
            reqwest({
                url:'/paper/getpradata/',
                methods:'get',
                type: 'json',
                success: function(data) {
                    self.paperdata = data.paper
                    console.log(data)
                }
            })
        }
    }
})