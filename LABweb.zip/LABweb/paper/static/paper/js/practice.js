var app = new Vue({
    el: '#index',
    data: {
       level_id : '',
       num : '',
       num2 : '',
       type : '',
        selected: '1',   // 这里选择默认项
        options: [
            { text: '点击选择题型', value: '1', disabled: '' },
            { text: '单选题', value: '1' },
            { text: '多选题', value: '2' },
            { text: '判断题', value: '3' },
            { text: '填空题', value: '4' },
        ]
    },
    mounted() {

    },
    methods: {
        topratestid1:function () {
            var self = this
            level_id = '1'
            self.level_id = level_id
            this.sendid()
            window.location.href = '/paper/pratest'
        },
        topratestid2:function () {
            var self = this
            level_id = '2'
            self.level_id = level_id
            this.sendid()
            window.location.href = '/paper/pratest'
        },
        topratestid3:function () {
            var self = this
            level_id = '3'
            self.level_id = level_id
            this.sendid()
            window.location.href = '/paper/pratest'
        },
        sendid: function () {
            var self = this
            reqwest({
                url: '/paper/getlevel_id/',
                method: 'get',
                type: 'json',
                data: {
                    level_id: self.level_id
                },
                success: function (data) {
                    console.log(data)
                }
            })
        },
        topratestnum:function(){
            var self = this
            console.log(self.num)
            reqwest({
                url:'/paper/getnum/',
                method:'get',
                data:{
                    num:self.num
                },
                success:function(data){
                    console.log(data)
                }
            })
            window.location.href = '/paper/pratest'
        },
        topratesttype:function(){
            var self = this
            console.log(self.selected)
            reqwest({
                url: '/paper/getselect/',
                method: 'get',
                data: {
                    selected: self.selected
                },
                success: function (data) {
                    console.log(data)
                }
            })
            window.location.href = '/paper/pratest'
        },
        topratestadd:function(){
            var self = this
            console.log(self.num2)
            console.log(self.selected)
            reqwest({
                url: '/paper/getadd/',
                method: 'get',
                data: {
                    num2:self.num2,
                    selected: self.selected
                },
                success: function (data) {
                    console.log(data)
                }
            })
            window.location.href = '/paper/pratest'
        },
    }
})